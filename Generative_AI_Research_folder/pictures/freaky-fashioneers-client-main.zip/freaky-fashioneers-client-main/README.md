## Project Overview

**SWIPE SWAP SAVE** is a web application designed to facilitate the swapping of clothing items among users. The platform encourages sustainable fashion practices by allowing individuals to trade clothing they no longer wear, reducing textile waste.

## Key Features

- **User Profiles**: Create and manage user profiles to track your swaps. Additioanlly, you can click on other users profiles to see all the items they offer.
- **Item Listings**: Upload clothing items with images, descriptions, and conditions.
- **Swiping Mechanism**: Easily swipe through the items in the catalouge with filters.
- **Search and Filter**: Browse available items using various filters to find what you need.
- **Messaging System**: Communicate with other users to negotiate swaps.
- **Forumn**: Discover and educate yourself on related fashion and sustainability topics.

## Target Audience

The application is aimed at individuals looking to refresh their wardrobe sustainably, and potentially without extra charge. Simply list clothes you no longer wear and make swap 
requests for clothes you wish to wear.

## Technologies Used

- **Frontend**: React, CSS
- **Backend**: Node.js, Express
- **Database**: PostgreSQL
- **Front End Hosting**: Vercel
- **Back end Hosting**: Render
- **Other**: Git, GitHub, REST APIs

## Code Features

- **Fisher-Yates Shuffle Algorithm**: The Fisher-Yates algorithm is used in `Home.jsx` to randomly shuffle the items displayed on the home page and after filter application. This ensures that users are presented with a new, randomized set of items each time they visit the page or apply filters. You can read more about the Fisher-Yates algorithm [here](https://en.wikipedia.org/wiki/Fisher–Yates_shuffle).

## Screenshots

![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)
![Home Page](assets/screenshots/home.png)


## Future Plans

- Implement a rating system for users and items after swaps.


This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh



### Setup Instructions

1. npm install

2. npm run dev