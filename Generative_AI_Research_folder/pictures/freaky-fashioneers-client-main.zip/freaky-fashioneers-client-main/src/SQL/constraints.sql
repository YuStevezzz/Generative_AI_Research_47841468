-- Create function to handle after_swap_insert logic
CREATE OR REPLACE FUNCTION handle_after_swap_insert()
RETURNS TRIGGER AS $$
BEGIN
    -- Delete items associated with the swap
    DELETE FROM items WHERE item_id = NEW.item1 OR item_id = NEW.item2;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create the trigger to call the function
CREATE TRIGGER after_swap_insert
AFTER INSERT ON swap
FOR EACH ROW
EXECUTE FUNCTION handle_after_swap_insert();

-- Create function to handle before_insert_swap logic
CREATE OR REPLACE FUNCTION check_payment_before_insert_swap()
RETURNS TRIGGER AS $$
BEGIN
    -- Check if either cash1 or cash2 is not null or zero
    IF (NEW.cash1 IS NOT NULL AND NEW.cash1 != 0) OR (NEW.cash2 IS NOT NULL AND NEW.cash2 != 0) THEN
        -- Check if user1 has a payment entry
        IF NOT EXISTS (SELECT 1 FROM payments WHERE user_id = NEW.user1) THEN
            RAISE EXCEPTION 'User1 does not have a valid payment record.';
        END IF;
        
        -- Check if user2 has a payment entry
        IF NOT EXISTS (SELECT 1 FROM payments WHERE user_id = NEW.user2) THEN
            RAISE EXCEPTION 'User2 does not have a valid payment record.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create the trigger to call the function
CREATE TRIGGER before_insert_swap
BEFORE INSERT ON swap
FOR EACH ROW
EXECUTE FUNCTION check_payment_before_insert_swap();

-- Create function to handle before_insert_review logic
CREATE OR REPLACE FUNCTION check_swap_before_insert_review()
RETURNS TRIGGER AS $$
BEGIN
    -- Check if a valid swap exists for the review
    IF NOT EXISTS (
        SELECT 1
        FROM swap
        WHERE (user1 = NEW.reviewer_id AND user2 = NEW.reviewee_id
               OR user1 = NEW.reviewee_id AND user2 = NEW.reviewer_id)
          AND (item1 = NEW.item_id OR item2 = NEW.item_id)
    ) THEN
        RAISE EXCEPTION 'The review cannot be added because no valid swap exists.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create the trigger to call the function
CREATE TRIGGER before_insert_review
BEFORE INSERT ON reviews
FOR EACH ROW
EXECUTE FUNCTION check_swap_before_insert_review();


CREATE OR REPLACE FUNCTION enforce_name_consistency()
RETURNS TRIGGER AS $$
BEGIN
    -- If the name is updated in profiles, update users
    IF TG_OP = 'UPDATE' AND NEW.name IS DISTINCT FROM OLD.name THEN
        UPDATE users
        SET name = NEW.name
        WHERE user_id = NEW.user_id;
    END IF;

    -- If the name is updated in users, update profiles
    IF TG_OP = 'UPDATE' AND NEW.name IS DISTINCT FROM OLD.name THEN
        UPDATE profiles
        SET name = NEW.name
        WHERE user_id = NEW.user_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create Trigger for profiles
CREATE TRIGGER update_profiles_name
AFTER UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION enforce_name_consistency();

-- Create Trigger for users
CREATE TRIGGER update_users_name
AFTER UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION enforce_name_consistency();

