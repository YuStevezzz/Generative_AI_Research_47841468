-- Create or Replace Users Table
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone_number VARCHAR(20),
    dob DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create or Replace Items Table
DROP TABLE IF EXISTS items;
CREATE TABLE items (
    item_id SERIAL PRIMARY KEY,
    seller_id INT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(50) CHECK (category IN (
        'tops', 'bottoms', 'dresses', 'outerwear', 'sportswear',
        'swimwear', 'suits', 'shoes', 'accessories'
    )),
    condition VARCHAR(10) CHECK (condition IN (
        'excellent', 'good', 'fair', 'poor'
    )),
    size VARCHAR(50),
    location VARCHAR(255),
    listed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    photos TEXT[],
    FOREIGN KEY (seller_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Create or Replace Swap Table
DROP TABLE IF EXISTS swap;
CREATE TABLE swap (
    swap_id SERIAL PRIMARY KEY,
    user1 INT,
    user2 INT,
    item1 INT,
    item2 INT,
    cash1 DECIMAL(10, 2),
    cash2 DECIMAL(10, 2),
    event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user1) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (user2) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Create or Replace Payments Table
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    user_id INT,
    card_number BYTEA,            
    card_expiry DATE,             
    card_holder_name VARCHAR(255), 
    card_cvv BYTEA,               
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create or Replace Reviews Table
DROP TABLE IF EXISTS reviews;
CREATE TABLE reviews (
    review_id SERIAL PRIMARY KEY,
    reviewer_id INT,
    reviewee_id INT,
    item_id INT,
    description TEXT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reviewer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE CASCADE
);

--CREATE profiles
CREATE TABLE profiles (
    user_id INT UNIQUE PRIMARY KEY,
    name VARCHAR(255) UNIQUE,
    location VARCHAR(255),
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE messages (
  message_id SERIAL PRIMARY KEY,
  sender_id INT REFERENCES users(user_id),
  receiver_id INT REFERENCES users(user_id),
  message_text TEXT NOT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


