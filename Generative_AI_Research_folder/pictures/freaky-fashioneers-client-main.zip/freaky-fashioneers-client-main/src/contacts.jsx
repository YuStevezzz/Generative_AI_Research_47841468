import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function RecentConversations({ userId }) {
  const [contacts, setContacts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchContacts = async () => {
      const response = await fetch(`/api/recent-contacts/${userId}`);
      const data = await response.json();
      setContacts(data);
    };

    fetchContacts();
  }, [userId]);

  return (
    <div>
      <h2>Recent Conversations</h2>
      <ul>
        {contacts.map(contact => (
          <li key={contact.contact_id}>
            <button onClick={() => navigate(`/chat/${contact.contact_id}`)}>
              Message with User {contact.contact_id}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RecentConversations;
