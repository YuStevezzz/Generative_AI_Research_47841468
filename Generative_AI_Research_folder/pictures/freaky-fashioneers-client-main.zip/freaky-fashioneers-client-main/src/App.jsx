import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import { useState, useContext } from "react";
import { useSwipeable } from "react-swipeable";
import "./App.css";
import ScrollToTop from "./ScrollToTop";
import { UserProvider, useUserContext } from "./UserContext.jsx"; // Corrected import
import ProtectedRoute from "./protectedRoute.jsx"; // Import ProtectedRoute

// Page components
import Landing from "./Components/Landing/Landing.jsx";
import Home from "./Components/Home/Home.jsx";
import Search from "./Components/Search/Search.jsx";
import AddClothes from "./Components/AddClothes/AddClothes/AddClothes/AddClothes.jsx";
import Forum from "./Components/Forum/Forum.jsx";
import Profile from "./Components/Profile/Profile.jsx";
import Login from "./Components/Login/Login.jsx";
import ItemDetails from "./Components/ItemDetails/ItemDetails.jsx";
import Contacts from "./contacts.jsx";
import SwappingGuide from "./Components/SwappingGuide/SwappingGuide.jsx";
import PointsInfo from "./Components/PointsInfo/PointsInfo.jsx";
import ProfileDetails from "./Components/ProfileEdit/ProfileEdit.jsx";
import ManageItems from './Components/Profile/ManageItems'; // Import the new component
import OtherProfile from './Components/OtherProfile/OtherProfile.jsx';
import UserSafety from './Components/UserSafety/UserSafety.jsx';

// Redirection Component for Messages
const RedirectToChat = () => {
  const { user } = useContext(UserContext); // Assuming you have a user state in context

  // Check if user is authenticated
  if (!user) {
    // Redirect to login if not authenticated
    window.location.href = '/login'; // Change this to your login route
    return null; // Return null because the user is being redirected
  }

  // If authenticated, redirect to the chat platform
  window.location.href = 'https://freakychat.in/';
  return null; // Return null because the user is being redirected
};

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false); // State for the side menu

  // Handling swipes
  const handlers = useSwipeable({
    onSwipedLeft: () => handleSwipe("left"),
    onSwipedRight: () => handleSwipe("right"),
  });

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <UserProvider>
      <Router>
        <div className="App">
          <header className="App-header">
            <div className="home-image">
              <Link
                to="/home"
                className="home-image"
                style={{ width: "50px", height: "50px" }}
              >
                <img
                  src="/assets/Images/sss_logo.png"
                  alt="Logo"
                  style={{ width: "100%", height: "auto" }}
                />
              </Link>
            </div>
            <div className="header-icons">
              <Link to="/search">
                <img
                  src="/assets/Images/save copy.png"
                  alt="Search"
                  className="header-icon search icon"
                />
              </Link>
              <Link to="/add-clothes">
                <img
                  src="/assets/Images/new_shirt.png"
                  alt="Add Clothes"
                  className="header-icon"
                />
              </Link>
              <div className="burger-menu-icon" onClick={toggleMenu}>
                <span className="burger-line"></span>
                <span className="burger-line"></span>
                <span className="burger-line"></span>
              </div>
            </div>
          </header>

          {/* Side Menu */}
          <div className={`side-menu ${isMenuOpen ? "open" : ""}`}>
            <button className="close-menu" onClick={toggleMenu}>
              ×
            </button>
            <nav className="menu-links">
              <Link to="/home" onClick={toggleMenu}>
                <img
                  src="/assets/Images/white_home.png"
                  alt="Home"
                  className="menu-icon"
                />
                Home
              </Link>
              <Link to="/search" onClick={toggleMenu}>
                <img
                  src="/assets/Images/white_search.png"
                  alt="Search"
                  className="menu-icon"
                />
                Search
              </Link>
              <Link to="/add-clothes" onClick={toggleMenu}>
                <img
                  src="/assets/Images/white_new_shirt.png"
                  alt="Add Clothes"
                  className="menu-icon"
                />
                List Item
              </Link>
              <Link to="/profile" onClick={toggleMenu}>
                <img
                  src="/assets/Images/white_profile.png"
                  alt="Profile"
                  className="menu-icon"
                />
                Profile
              </Link>
              <Link to="/forum" onClick={toggleMenu}>
                <img
                  src="/assets/Images/white_community.png"
                  alt="News Forum"
                  className="menu-icon"
                />
                News Forum
              </Link>
              {/* Redirect to external chat platform on click */}
              <a
                href="https://freakychat.in/"
                className="menu-icon"
                onClick={toggleMenu} // Close the menu after redirect
                style={{ display: 'flex', alignItems: 'center', color: 'white', textDecoration: 'none', paddingBottom: '15px', borderBottom: '1px solid #fff' }} // Match other link styles
              >
                <img
                  src="/assets/Images/white_message.png"
                  alt="Contacts"
                  className="menu-icon"
                />
                Contacts
              </a>
              <Link to="/" onClick={toggleMenu}>
                <img
                  src="/assets/Images/white_logout.png"
                  alt="Logout"
                  className="menu-icon"
                />
                Logout
              </Link>
            </nav>
          </div>

          {/* Overlay when menu is open */}
          {isMenuOpen && (
            <div className="menu-overlay" onClick={toggleMenu}></div>
          )}

          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/home" element={<Home />} />
            <Route path="/search" element={<Search />} />
            <Route path="/add-clothes" element={<AddClothes />} />
            <Route path="/forum" element={<Forum />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/item/:id" element={<ItemDetails />} />
            <Route path="/swapping-guide" element={<SwappingGuide />} />
            <Route path="/points-info" element={<PointsInfo />} />
            <Route path="/profile-details" element={<ProfileDetails />} />
            <Route path="/manage-items" element={<ManageItems />} />
            <Route path="/other-profile/:username" element={<OtherProfile />} />
            <Route path="/UserSafety" element={<UserSafety />} />

            {/* Redirect messages route to external chat platform */}
            <Route path="/messages/:contactId" element={<RedirectToChat />} />
            {
            <Route
              path="/contacts"
              element={
                <ProtectedRoute>
                  <Contacts />
                </ProtectedRoute>
              }
            />
            }
          </Routes>
        </div>
      </Router>
    </UserProvider>
  );
}

export default App;
