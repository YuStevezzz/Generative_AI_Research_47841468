// ProtectedRoute.jsx
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useUserContext } from './UserContext';

const ProtectedRoute = ({ children }) => {
  const { user } = useUserContext(); // Get user state

  if (!user) {
    // If user is not logged in, redirect to login
    return <Navigate to="/login" />;
  }

  // If user is logged in, render the protected component
  return children;
};

export default ProtectedRoute;
