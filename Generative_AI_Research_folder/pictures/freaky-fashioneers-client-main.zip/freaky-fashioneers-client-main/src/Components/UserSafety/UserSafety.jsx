import React from "react";
import "./UserSafety.css";

const SwappingGuide = () => {
  return (
    <main className="safety-main">
      <div className="safety-intro-section">
        <div className="safety-swap-header">
          <h1>Your Guide to Safe Swapping</h1>
        </div>
        <div className="safety-p-container">
          <p>
            Swapping clothing can be a fun, sustainable, and community-focused activity.
            However, it's important to prioritize safety, both online and in person. Here are some 
            helpful tips to keep you and your items safe while swapping.
          </p>
        </div>
      </div>

      <div className="safety-steps-section">
        <h3>General Online Safety</h3>
        <div className="safety-step-card">
        <img src="/assets/Images/online-safety-act.jpg" alt="Online Safety" className="safety-image" />
          <div className="safety-tip">
            <p>Never share your password or sensitive information with others.</p>
          </div>
          <div className="safety-tip">
            <p>Avoid clicking on suspicious links or giving out personal information in messages.</p>
          </div>
          <div className="safety-tip">
            <p>Enable two-factor authentication for extra security.</p>
          </div>
        </div>

        <h3>Clothing Swap-Specific Safety</h3>
        <div className="safety-step-card">
        <img src="/assets/Images/clotheshanging.jpg" alt="Online Safety" className="safety-image" />
          <div className="safety-tip">
            <p>Be cautious of items priced too low for their brand or quality—this could indicate a scam or poor quality.</p>
          </div>
          <div className="safety-tip">
            <p>Check item descriptions carefully and ask for additional photos to verify authenticity.</p>
          </div>
        </div>

        <h3>Safe In-Person Swaps</h3>
        <div className="safety-step-card">
        <img src="/assets/Images/vinnies.jpg" alt="Online Safety" className="safety-image" />
          <div className="safety-tip">
            <p>Meet in public, well-lit areas if you’re comfortable with in-person swaps.</p>
          </div>
          <div className="safety-tip">
            <p>Bring a friend to your swap meet, if possible, for added safety.</p>
          </div>
          <div className="safety-tip">
            <p>
              If you feel uneasy about meeting someone in person, consider using our drop-off method, 
              where you can exchange items at a designated location, like an op-shop, for a more secure experience.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
};

export default SwappingGuide;
