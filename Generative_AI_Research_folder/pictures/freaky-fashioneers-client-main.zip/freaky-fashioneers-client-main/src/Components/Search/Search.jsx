import React, { useState, useEffect } from 'react';
import './Search.css';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useUserContext } from '../../UserContext';
import Filter from './Filter'; // Import the Filter component

function Search() {
  const { user } = useUserContext(); // Get user from context
  const navigate = useNavigate(); // Hook to programmatically navigate
  const location = useLocation(); // Hook to get the current location

  // State to store the items
  const [items, setItems] = useState([]);
  
  // State to control the visibility of the filter dropdown
  const [isFilterOpen, setFilterOpen] = useState(false);

  // State for the search input
  const [searchTerm, setSearchTerm] = useState('');

  // State to manage selected categories and conditions for filtering
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedConditions, setSelectedConditions] = useState([]);

  // Function to toggle the filter dropdown
  const toggleFilter = () => {
    setFilterOpen(!isFilterOpen);
  };

  // Function to fetch items from the server, with an optional search parameter
  const fetchItems = async () => {
    try {
        // Construct query parameters
        const queryParams = new URLSearchParams({
            search: searchTerm || '', // Ensure there's always a value
            category: selectedCategories.length ? selectedCategories.join(',') : null,
            condition: selectedConditions.length ? selectedConditions.join(',') : null,
        }).toString();

        // Construct the complete URL
        const url = `https://freaky-fashioneers-service.onrender.com/items?${queryParams}`;

        console.log('Fetching URL:', url); // Log the constructed URL

        // Fetch the data, explicitly specifying the GET method
        const response = await fetch(url, {
            method: 'GET', // Explicitly specify the GET method
        });

        // Check if the response is ok (status in the range 200-299)
        if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.statusText}`);
        }

        const data = await response.json();
        setItems(data);
    } catch (error) {
        console.error('Error fetching items:', error);
    }
};

  // Fetch items when the component mounts or the search term or filters change
  useEffect(() => {
    fetchItems();
  }, [searchTerm, selectedCategories, selectedConditions]);

  // Handle search input change
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value); // Update searchTerm as the user types
  };

  // Function to handle search on Enter key press
  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault(); // Prevent default form submission
      fetchItems(); // Fetch items based on the current search term
    }
  };

  // Function to handle the "Contact Seller" button click
  const handleContactSeller = (sellerId) => {
    if (!user) {
      // Redirect to login and pass the current path as state
      navigate('/login', { state: { from: { pathname: `/contact-seller/${sellerId}` } } });
    } else {
      // Redirect to the contact seller page
      navigate(`/contact-seller/${sellerId}`);
    }
  };

  return (
    <div className="search-page">
      <div className="search-bar-container">
        <input
          type="text"
          placeholder="Search Second-Hand Clothes"
          className="search-bar"
          value={searchTerm}
          onChange={handleSearchChange} // Update state as user types
          onKeyDown={handleKeyDown} // Add key down listener
        />
        <button className="search-icon-btn" onClick={fetchItems}>
          <img src="/assets/Images/search.png" alt="Search" />
        </button>
        <button className="filter-btn" onClick={toggleFilter}>
          Filters
        </button>
        <button className="filter-icon-btn" onClick={toggleFilter}>
          <img src="/assets/Images/filter.png" alt="Filter"/>
        </button>
      </div>

      {/* Dropdown for Filters */}
      {isFilterOpen && (
        <Filter
          selectedCategories={selectedCategories}
          setSelectedCategories={setSelectedCategories}
          selectedConditions={selectedConditions}
          setSelectedConditions={setSelectedConditions}
          onFilter={setItems} // Pass the function to update items
          toggleFilter={toggleFilter} // Optional: close the filter dropdown after selecting
        />
      )}

      <div className="clothes-container">
        <div className="clothes-grid">
          {Array.isArray(items) && items.length > 0 ? ( // Ensure items is an array and has elements
            items.map(item => (
              <div className="clothes-item" key={item.item_id}>
                <div className="clothes-item-spacer"> </div>
                <Link to={`/item/${item.item_id}`} className="item-link">
                  <img src={item.photos[0]} alt={item.title} />
                  <h3 className="item-title">{item.title}</h3>
                </Link>
                <button onClick={() => handleContactSeller(item.sellerId)} className="contact-seller-btn">
                  Contact Seller
                </button>
              </div>
            ))
          ) : (
            <p>No items found.</p> // Message when no items are found
          )}
        </div>
      </div>
    </div>
  );
}

export default Search;
