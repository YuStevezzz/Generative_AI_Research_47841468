import React, { useState, useEffect } from 'react';

import './Search.css'; // Ensure you have the styles defined in this file

function Filter({ selectedCategories, setSelectedCategories, selectedConditions, setSelectedConditions, onFilter }) {
  const [showConditions, setShowConditions] = useState(false); // State to control the visibility of conditions
  const [showCategories, setShowCategories] = useState(false); // State to control the visibility of categories

  // Function to toggle category selection
  const toggleCategory = (category) => {
    setSelectedCategories((prevSelected) => {
      if (prevSelected.includes(category)) {
        return prevSelected.filter((c) => c !== category); // Remove category if already selected
      } else {
        return [...prevSelected, category]; // Add category if not selected
      }
    });
  };

  // Function to toggle condition selection
  const toggleCondition = (condition) => {
    setSelectedConditions((prevSelected) => {
      if (prevSelected.includes(condition)) {
        return prevSelected.filter((c) => c !== condition); // Remove condition if already selected
      } else {
        return [...prevSelected, condition]; // Add condition if not selected
      }
    });
  };

  // Function to fetch filtered items based on selected categories and conditions


  // Effect to fetch filtered items whenever filters change
  useEffect(() => {
  }, [selectedCategories, selectedConditions]); // Fetch items when filters change

  return (
    <div className="dropdown-menu">
      <div>
        <span>Categories:
          <button onClick={() => setShowCategories(!showCategories)}>Show</button>
        </span>
        {showCategories && (
          <div className="category-options">
            <label>
              Tops
              <input
                type="checkbox"
                onChange={() => toggleCategory('tops')}
                checked={selectedCategories.includes('tops')}
              />
            </label>
            <label>
              Bottoms
              <input
                type="checkbox"
                onChange={() => toggleCategory('bottoms')}
                checked={selectedCategories.includes('bottoms')}
              />
            </label>
            <label>
              Dresses
              <input
                type="checkbox"
                onChange={() => toggleCategory('dresses')}
                checked={selectedCategories.includes('dresses')}
              />
            </label>
            <label>
              Outerwear
              <input
                type="checkbox"
                onChange={() => toggleCategory('outerwear')}
                checked={selectedCategories.includes('outerwear')}
              />
            </label>
            <label>
              Sportswear
              <input
                type="checkbox"
                onChange={() => toggleCategory('sportswear')}
                checked={selectedCategories.includes('sportswear')}
              />
            </label>
            <label>
              Swimwear
              <input
                type="checkbox"
                onChange={() => toggleCategory('swimwear')}
                checked={selectedCategories.includes('swimwear')}
              />
            </label>
            <label>
              Suits
              <input
                type="checkbox"
                onChange={() => toggleCategory('suits')}
                checked={selectedCategories.includes('suits')}
              />
            </label>
            <label>
              Shoes
              <input
                type="checkbox"
                onChange={() => toggleCategory('shoes')}
                checked={selectedCategories.includes('shoes')}
              />
            </label>
          </div>
        )}
      </div>
      <div>
        <span>Conditions:
          <button onClick={() => setShowConditions(!showConditions)}>Show</button>
        </span>
        
        {showConditions && (
          <div className="condition-options">
            <label>
              Excellent
              <input
                type="checkbox"
                onChange={() => toggleCondition('excellent')}
                checked={selectedConditions.includes('excellent')}
              />
            </label>
            <label>
              Good
              <input
                type="checkbox"
                onChange={() => toggleCondition('good')}
                checked={selectedConditions.includes('good')}
              />
            </label>
            <label>
              Fair
              <input
                type="checkbox"
                onChange={() => toggleCondition('fair')}
                checked={selectedConditions.includes('fair')}
              />
            </label>
            <label>
              Poor
              <input
                type="checkbox"
                onChange={() => toggleCondition('poor')}
                checked={selectedConditions.includes('poor')}
              />
            </label>
          </div>
        )}
      </div>
    </div>
  );
}

export default Filter;
