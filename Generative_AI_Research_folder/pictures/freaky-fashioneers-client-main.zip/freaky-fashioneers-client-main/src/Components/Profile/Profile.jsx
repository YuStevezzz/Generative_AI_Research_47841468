import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../Profile/Profile.css";
import { useUserContext } from '../../UserContext';

const Profile = () => {
  const navigate = useNavigate();
  const { user } = useUserContext();
  const [userData, setUserData] = useState(null);
  const [userItems, setUserItems] = useState([]);

  // Effect to fetch user data when the user changes
  useEffect(() => {
    //ensure the user is logged in and if not send them to login page, redirect back afterwards
    if (!user || !user.userId) {
      navigate('/login', { state: { from: { pathname: '/profile' } } });
    } else {
      //if not send fetch request with user id
      const fetchUserData = async () => {
        try {
          const profileResponse = await fetch(
            `https://freaky-fashioneers-service.onrender.com/profiles/${user.userId}`
          );
          if (!profileResponse.ok) {
            throw new Error("Failed to fetch profile details");
          }
          const profileData = await profileResponse.json();
          setUserData(profileData);
          //fetch with full query so it suit the items.js api requirements
          const itemsResponse = await fetch(
            `https://freaky-fashioneers-service.onrender.com/items?search=&category=null&condition=null&seller_id=${user.userId}`
          );
          if (!itemsResponse.ok) {
            throw new Error("Failed to fetch user items");
          }
          const itemsData = await itemsResponse.json();
          //set the user item data
          setUserItems(itemsData);
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      };
      fetchUserData();
    }
  }, [user, navigate]);
  //get the user data
  const keys = ['token', 'userId', 'username', 'name', 'email', 'phone_number', 'dob'];
  const retrievedData = {};
  for (const key of keys) {
    retrievedData[key] = localStorage.getItem(key);
  }

  return (
    <div className="profile-page">
      <div className="profile-container">
        <div className="profile-content">
          <div className="profile-info">
            <div className="profile-pic">
              <img src="/assets/Images/profile.png" alt="Profile" />
            </div>
            <h2>{retrievedData['name']}</h2>
            <h3>{retrievedData['email']}</h3>
            <p className="about-me">{retrievedData['phone_number']}</p>
          </div>
          <button
            className="edit-profile-button"
            onClick={() =>
              navigate("/profile-details", {
                state: { profileData: retrievedData },
              })
            }
          >
            Edit Profile
          </button>
        </div>
      </div>

      <div className="items-container">
        <div className="profile-content">
          <div className="your-items">
            <h3>Your Items</h3>
            <div className="items-grid">
              {userItems.slice(0, 2).map((item, index) => (
                <div className="item" key={index}>
                  {console.log("Image URL:", item.photos[0])} 
                  {item.photos && item.photos.length > 0 && item.photos[0] ? (
                    <img src={item.photos[0]} alt={item.title} />
                  ) : (
                    <p>No image available</p>
                  )}
                  <p>{item.title}</p>
                </div>
              ))}
              {userItems.length > 2 && (
                <div className="item more-items">
                  <div className="plus-item">
                    <p>+{userItems.length - 2}</p>
                  </div>
                  <p>{userItems.length - 2} more items</p>
                </div>
              )}
            </div>
          </div>
          <button
            className="manage-items-button"
            onClick={() => navigate("/manage-items")}
          >
            Manage Items
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
