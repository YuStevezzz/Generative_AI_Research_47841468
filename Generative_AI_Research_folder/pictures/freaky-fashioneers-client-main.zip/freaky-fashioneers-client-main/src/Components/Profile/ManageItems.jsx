import React, { useEffect, useState } from 'react';
import { useUserContext } from '../../UserContext';
import { useNavigate, useParams } from 'react-router-dom';
import './ManageItems.css';

const ManageItems = () => {
    const { user } = useUserContext();
    const [userItems, setUserItems] = useState([]);
    const navigate = useNavigate();
    const { sellerId } = useParams();
    //use effect used to fetch all the items of that user
    useEffect(() => {
        if (!user || !user.userId) {
            navigate('/login');
        } else {
            const fetchUserItems = async () => {
                try {
                    const itemsResponse = await fetch(
                        //get request with the seller if or user_id
                        `https://freaky-fashioneers-service.onrender.com/items?search=&category=null&condition=null&seller_id=${sellerId || user.userId}`
                    );
                    if (!itemsResponse.ok) {
                        throw new Error("Failed to fetch user items");
                    }
                    const itemsData = await itemsResponse.json();
                    console.log(itemsData); // Log to inspect the structure of the data
                    setUserItems(itemsData);
                } catch (error) {
                    console.error("Error fetching items:", error);
                }
            };
            fetchUserItems();
        }
    }, [user, navigate, sellerId]);
    //handle the commands when the user presses delete item
    const handleDeleteItem = async (itemId) => {
        console.log("Deleting item with ID:", itemId); // Log the itemId
        const confirmed = window.confirm("Are you sure you want to delete this item?");
        if (!confirmed) return; // Stop if the user clicks No
        
        try {
            const deleteResponse = await fetch(`https://freaky-fashioneers-service.onrender.com/items/${itemId}`, {
                method: 'DELETE',
            });
            if (!deleteResponse.ok) {
                throw new Error("Failed to delete item");
            }
            // Update state to remove the deleted item from the UI
            setUserItems((prevItems) => prevItems.filter(item => item.item_id !== itemId));
        } catch (error) {
            console.error("Error deleting item:", error);
        }
    };

    return (
        <div className="manage-manageItemsPage">
            <h2>{sellerId ? "Items for Sale" : "Your Items"}</h2>
            <div className="manage-itemsGrid">
                {userItems.length > 0 ? (
                    userItems.map((item) => (
                        <div className="manage-item" key={item.item_id}>
                            {item.photos && item.photos.length > 0 && item.photos[0] ? (
                                <img src={item.photos[0]} alt={item.title} />
                            ) : (
                                <p>No image available</p>
                            )}
                            <h3>{item.title}</h3>
                            {user && user.userId === item.seller_id && (
                                <button onClick={() => handleDeleteItem(item.item_id)}>Delete Item</button>
                            )}
                        </div>
                    ))
                ) : (
                    <p>No items found.</p>
                )}
            </div>
        </div>
    );
};

export default ManageItems;
