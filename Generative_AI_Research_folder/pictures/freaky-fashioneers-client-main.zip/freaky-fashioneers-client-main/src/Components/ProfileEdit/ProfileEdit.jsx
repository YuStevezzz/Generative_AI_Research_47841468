import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../ProfileEdit/ProfileEdit.css";

const ProfileDetails = () => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const profile = state?.profileData; // Make sure this is being passed correctly
  console.log(profile, "state");

  // State variables for profile details
  const [name, setName] = useState(profile?.name || ""); // Set default value
  const [location, setLocation] = useState(profile?.location || ""); // Set default value
  const [description, setDescription] = useState(profile?.description || ""); // Set default value
  const [photo, setPhoto] = useState(profile?.photo || ""); // Set default value
  const [preview, setPreview] = useState(photo); // State to store the preview of the image

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result); // Update the photo state with the image data URL
        setPreview(reader.result); // Update the preview state
      };
      reader.readAsDataURL(file); // Read the file as a data URL
    }
  };

  // Effect to update state when profile changes
  useEffect(() => {
    if (profile) {
      setName(profile.name);
      setLocation(profile.location);
      setDescription(profile.description);
      setPhoto(profile.photo);
      setPreview(profile.photo);
    }
  }, [profile]);

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission

    const editedProfile = {
      name,
      description,
      location,
      photo,
      id: profile?.id,
    };

    try {
      // Call API to edit profile here
      navigate("/profile"); // Redirect to profile page upon success
    } catch (error) {
      console.error("Error saving profile:", error);
    }
  };

  return (
    <main className="profile-edit">
      <div className="page">
        <div className="page-content">
          <div className="row justify-content-center">
            <div className="card col-lg-6" id="page-card">
              <h3 className="profile-heading text-center mb-4">Edit Profile</h3>
              <form onSubmit={handleSubmit}>
                {/* Name Field */}
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">
                    Name
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>

                {/* Location */}
                <div className="mb-3">
                  <label htmlFor="location" className="form-label">
                    Location
                  </label>
                  <textarea
                    className="form-control"
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    rows="3"
                    required
                  ></textarea>
                </div>

                {/* Description */}
                <div className="mb-3">
                  <label htmlFor="description" className="form-label">
                    Description
                  </label>
                  <textarea
                    className="form-control"
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows="3"
                    required
                  ></textarea>
                </div>

                {/* Photo Upload */}
                <div className="mb-3">
                  <label htmlFor="photo" className="form-label">
                    Photo
                  </label>
                  <input
                    type="file"
                    className="form-control"
                    id="photo"
                    accept="image/*"
                    onChange={handlePhotoChange}
                    required
                  />
                  {preview && (
                    <img
                      src={preview}
                      alt="Profile Preview"
                      className="img-preview"
                      style={{
                        marginTop: "10px",
                        width: "100px",
                        height: "100px",
                        objectFit: "cover",
                      }}
                    />
                  )}
                </div>

                {/* Submit Button */}
                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default ProfileDetails;
