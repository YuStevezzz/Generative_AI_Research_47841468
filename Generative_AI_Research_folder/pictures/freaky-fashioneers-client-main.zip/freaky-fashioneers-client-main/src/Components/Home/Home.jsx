import React, { useState, useEffect } from 'react';
import { useSwipeable } from "react-swipeable";
import { Link, useNavigate } from "react-router-dom";
import "./Home.css";
import Filter from '../Search/Filter'; // Import the Filter component

const Home = () => {
  const [items, setItems] = useState([]); // All items
  const [filteredItems, setFilteredItems] = useState([]); // Filtered items
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showFilter, setShowFilter] = useState(false); // State to control filter visibility
  const [selectedCategories, setSelectedCategories] = useState([]); // Store selected categories
  const [selectedConditions, setSelectedConditions] = useState([]); // Store selected conditions
  const navigate = useNavigate(); // Hook for navigation

  // Shuffle function using Fisher-Yates algorithm
  const shuffleArray = (array) => {
    // Create a copy of the array to avoid mutating the original data
    const shuffled = array.slice();
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  // Fetch items from the API
  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await fetch(`https://freaky-fashioneers-service.onrender.com/items`);
        const data = await response.json();
        const shuffledData = shuffleArray(data);
        setItems(data); // Store all items
        setFilteredItems(data); // Initialize filtered items with all items
      } catch (error) {
        console.error('Error fetching items:', error);
      }
    };

    fetchItems();
  }, []);

  // Update filtered items whenever selected categories or conditions change
  useEffect(() => {
    const applyFilters = () => {
      const filtered = items.filter(item => {
        const categoryMatch = selectedCategories.length === 0 || selectedCategories.includes(item.category);
        const conditionMatch = selectedConditions.length === 0 || selectedConditions.includes(item.condition);
        return categoryMatch && conditionMatch;
      });
      const shuffledFilteredItems = shuffleArray(filtered); // Shuffle filtered items
      setFilteredItems(shuffledFilteredItems); // Update filtered items
      setCurrentIndex(0); // Reset current index when filters are applied
    };

    applyFilters();
  }, [selectedCategories, selectedConditions, items]);

  // Handling swipes
  const handlers = useSwipeable({
    onSwipedLeft: () => handleSwipe("left"),
    onSwipedRight: () => handleSwipe("right"),
  });

  const handleSwipe = (direction) => {
    if (direction === "left") {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % filteredItems.length);
    } else if (direction === "right") {
      const currentItem = filteredItems[currentIndex];
      if (currentItem && currentItem.item_id) {
        navigate(`/item/${currentItem.item_id}`);
      }
    }
  };

  // **Loading state check**
  if (filteredItems.length === 0) {
    return <div>Loading items...</div>;
  }

  const currentItem = filteredItems[currentIndex];

  return (
    <main className="main-dashboard">
      <div className="swipe-section" {...handlers}>
        <h3 className="swipeHeading">Discover More Clothing</h3>
        <div className="swipe-card">
          <h3>{currentItem.title}</h3>
          <img
            src={currentItem.photos[0]}
            alt={currentItem.title}
          />
          <div className="product-details">
            <p>Brand: {currentItem.brand}</p>
            <p>Size: {currentItem.size}</p>
            <p>Condition: {currentItem.condition}</p>
          </div>
        </div>
      </div>

      <div className="home-container">
        <button className="filter-button" onClick={() => setShowFilter(!showFilter)}>
          {showFilter ? "Hide Filters" : "Show Filters"}
        </button>

        {showFilter && (
          <Filter 
            selectedCategories={selectedCategories} 
            setSelectedCategories={setSelectedCategories} 
            selectedConditions={selectedConditions} 
            setSelectedConditions={setSelectedConditions} 
            onFilter={() => console.log("Filter applied")} // Placeholder for filter action
          />
        )}

        <div className="dashboard">
          <div className="quiz">
            <h3>Your Fashion Personality</h3>
          </div>
          <div className="quiz-button1">
            <Link to="/" className="quiz-button">
              Take quiz  ➡
            </Link>
          </div>
          <div className="swap-stats">
            <h3>Clothes Saved: 10</h3>
          </div>
          <div className="points">
            <h3>Swap Points: 10, 000</h3>
          </div>
          <Link to="/points-info" className="points-button">
            Redeem Points
          </Link>
        </div>
      </div>
    </main>
  );
};

export default Home;
