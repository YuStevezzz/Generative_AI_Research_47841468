// OtherProfile.js

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom'; // Import Link
import { useUserContext } from '../../UserContext'; // Import user context
import './OtherProfile.css';

const OtherProfile = () => {
    const { username } = useParams(); // Get the username from the URL
    const [userItems, setUserItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const { user } = useUserContext(); // Get user from context
    //fetch the users items based on their username as it is unique
    useEffect(() => {
        const fetchUserItems = async () => {
            try {
                //get request
                const itemsResponse = await fetch(`https://freaky-fashioneers-service.onrender.com/items/user/${username}`);
                if (!itemsResponse.ok) {
                    throw new Error('Failed to fetch user items');
                }
                // get items is json form
                const itemsData = await itemsResponse.json();
                //log data for checking reasons
                console.log("ItemsData: ", itemsData);
                setUserItems(itemsData);
            } catch (error) {
                console.error('Error fetching user items:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchUserItems();
    }, [username]);
    //render loading state while images are being fetched 
    if (loading) {
        return <div>Loading user's items...</div>;
    }
    
    return (
        <div className='profile-page'>
            <div className="other-profile">
                <h2>{username}'s Inventory</h2>
                <div className="items-grid">
                    {userItems.length > 0 ? (
                        userItems.map((item) => (
                            <div className="item" key={item.item_id}>
                                <Link to={`/item/${item.item_id}`}>
                                    <img 
                                        src={item.photos[0]} 
                                        alt={item.title} 
                                        onError={(e) => {
                                            e.target.src = 'path-to-fallback-image.jpg';
                                            console.error('Error loading image for item:', item.title);
                                        }}
                                    />
                                </Link>
                                <h3>{item.title}</h3>
                            </div>
                        ))
                    ) : (
                        <p>No items found for this user.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default OtherProfile;
