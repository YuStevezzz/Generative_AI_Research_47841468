import React from 'react';
import { Link } from 'react-router-dom';
import '../Forum/Forum.css';
import postImage from "../../../public/assets/Images/post.jpg"; // Assuming this is your post image

//display posts with links for websites they take them to
const posts = [
  { 
    id: 1, 
    title: "Swapper Safety Tips", 
    content: "Here's how to stay safe while swapping your clothes", 
    author: "SSS Official Team", 
    avatar: "/assets/Images/leaf.png",
    image: "/assets/Images/post.jpg",
    time: "12h ago",
    likes: 110,
    comments: 4,
    link: "/UserSafety"
  },
  { 
    id: 2, 
    title: "Become an Expert Swapper", 
    content: "Our guide will help you maximise your swapping potential.", 
    author: "SSS Official Team", 
    avatar: "/assets/Images/leaf.png",
    image: "/assets/Images/effortless-trading.jpg",
    time: "2d ago",
    likes: 13,
    comments: 9,
    link: "/swapping-guide"
  },
  { 
    id: 3, 
    title: "10 Tips to Freshen Your Wardrobe", 
    content: "Discover simple strategies to care for, and extend the life of your favorite clothes.", 
    author: "SSS Official Team", 
    avatar: "/assets/Images/leaf.png",
    image: "/assets/Images/get-new-clothes.jpg",
    time: "06/10",
    likes: 58,
    comments: 18,
    link: ""
  },
  // Add more posts here
];

//make number of likes resposive to letters
const formatLikes = (num) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k';
  }
  return num.toString();
};

const Forum = () => {
  return (
    <div className='forum-page'>
      <div className="forum-container">
        {posts.map((post) => (
          <Link to={post.link} key={post.id} className="post-card-link">
            <div key={post.id} className="post-card">
              <div className="post-header">
                <img src={post.avatar} alt="user avatar" className="user-avatar"/>
                <div className="post-header-text">
                  <p className="user-name">{post.author}</p>
                  <p className="post-time">{post.time}</p>
                </div>
              </div>

              <div className="post-content">
                <img src={post.image || postImage} alt="Post visual content" />
                <h3>{post.title}</h3>
                <p>{post.content}</p>
              </div>

              <div className="post-interactions">
                <span className="likes">{formatLikes(post.likes)} likes</span>
                {/* Removed comments display */}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default Forum;
