import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSwipeable } from "react-swipeable";
import "../SwappingGuide/SwappingGuide.css";
import step1Image from "/assets/Images/signup.png";
import step2Image from "/assets/Images/listing.png";
import step3Image from "/assets/Images/swap.png";
import step4Image from "/assets/Images/pickup.png";

const steps = [
  {
    id: 1,
    name: "Step 1: Sign Up",
    image: step1Image,
    text: "Create your free account personalise it. Browse clothing items our users have listed!",
  },
  {
    id: 2,
    name: "Step 2: Upload Your Items",
    image: step2Image,
    text: "List your clothes quickly with our easy-to-use platform to complete your profile. This makes it easy for you to create swap offers with other users.",
  },
  {
    id: 3,
    name: "Step 3: Make a Swap",
    image: step3Image,
    text: "Browse other user listed clothing items for one you like, and reach out to them to organise a swap. Remember to be friendly!",
  },
  {
    id: 4,
    name: "Step 4: Collect Your Swap",
    image: step4Image,
    text: "Collect and ship your clothing items at our dedicated facilities or at a partnered op-shop!",
  },
];

const SwappingGuide = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Handling swipes
  const handlers = useSwipeable({
    onSwipedLeft: () => handleSwipe("left"),
    onSwipedRight: () => handleSwipe("right"),
  });

  const handleSwipe = (direction) => {
    if (direction === "left" && currentIndex < steps.length - 1) {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % steps.length);
    } else if (direction === "right" && currentIndex > 0) {
      setCurrentIndex((prevIndex) =>
        prevIndex === 0 ? steps.length - 1 : prevIndex - 1
      );
    }
  };

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) => Math.max(prevIndex - 1, 0));
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => Math.min(prevIndex + 1, steps.length - 1));
  };

  const currentStep = steps[currentIndex];
  return (
    <main>
      <div className="intro-section">
        <div className="swap-header">
          <h1>Your Guide to Swapping</h1>
        </div>
        <div className="p-container">
          <p>
            Clothing swaps are a sustainable and ethical alternative to fast
            fashion. By swapping clothes, you're reducing waste, cutting down on
            the demand for new production, and contributing to a more
            environmentally responsible fashion cycle.
            <br></br>
            <br></br>Scroll down to learn how you can do this with us for free!
          </p>
        </div>
      </div>

      <div className="steps-section" {...handlers}>
        <div className="steps-title">
          <h3> How It Works </h3>
        </div>
        <div className="swipe-card">
          <h3>{currentStep.name}</h3>
          <img src={currentStep.image} alt={currentStep.name} />
          <div className="product-details">
            <p>{currentStep.text}</p>
          </div>
          <div></div>
        </div>
        <div className="sub-text">
          <h3>Swipe to see steps -&gt;</h3>
        </div>
        <br></br>
      </div>

      <div className="section-three">
        <div className="card accept">
          <div className="accept-icon">✔ We Accept </div>
          <div className="text">
            <p>- Fast fashion brands</p>
            <p>- Mid-range to high-end brands and vintage pieces</p>
            <p className="small">
              - Genuine pieces from high-end brands (subject to authentication)
            </p>
          </div>
        </div>

        <div className="card decline">
          <div className="accept-icon">✖ Don't Accept</div>
          <div className="text">
            <p>- Items with:</p>
            <p>- holes, odours, stains, signs of wear or damage </p>
            <p>
              - snags in the fabric, broken zips, pulled threads, worn out
              elastics, missing buttons{" "}
            </p>
          </div>
        </div>
      </div>
    </main>
  );
};

export default SwappingGuide;
