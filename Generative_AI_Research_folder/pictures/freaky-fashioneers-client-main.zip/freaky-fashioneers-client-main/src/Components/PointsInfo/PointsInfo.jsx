import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSwipeable } from "react-swipeable";
import "../PointsInfo/PointsInfo.css";

const PointsInfo = () => {
  return (
    <main>
      <div className="first-section">
        <div className="swap-header">
          <h1>Redeem Your Points</h1>
        </div>
        <div className="option-one">
          <h3 className="points-p1">1. Claim Them In an Unequal Swap</h3>
          <img src="/assets/Images/swap3.png"></img>
          <p className="points-p11">
            Claiming points in an unequal swap for a discount allows you to
            exchange your Swap Points as a discounts. This method lets you
            maximise your swap potential. Start leveraging your points today by
            making a swap offer!
          </p>
        </div>
        <div className="option-two">
          <h3 className="points-p2">2. Claim as Gift-Card</h3>
          <img src="/assets/Images/giftcard.png"></img>
          <p className="points-p22">
            Claiming swap points as gift cards for thrift stores or other shops
            is another way to turn your Swap Points into tangible rewards. By
            exchanging your points, you can receive gift cards that can be used
            at various participating Op-Shops, allowing you to shop for unique
            items or gifting them to a friend!
          </p>
          <a
            className="link"
            href="https://www.prezzee.com.au/store/?utm_source=google&utm_medium=cpc&utm_campaign=au_agnostic_search_generic_gift-cards_generic_exact&utm_term=online%20gift%20cards&gad_source=1&gclid=Cj0KCQjw05i4BhDiARIsAB_2wfASpsc21o_EmyzawVU29WGPVmJ3ZpS2h_w0pn9IbH0YObDr5VNGAK4aAob4EALw_wcB"
          >
            Redeem Swap Points as Gift Card
          </a>
        </div>
        <div className="option-three">
          <h3 className="points-p3">
            3. Donate to a Sustainability Charity of Your Choice
          </h3>
          <img src="/assets/Images/donate.png"></img>
          <p className="points-p33">
            Claiming swap points as donations to a sustainability charity of
            your choice allows you to turn your loyalty points into meaningful
            contributions. By exchanging your points, you can support various
            environmental initiatives and make a positive impact on the planet.
            Start donating your points today and help foster a greener future!
          </p>
        </div>
      </div>
    </main>
  );
};

export default PointsInfo;
