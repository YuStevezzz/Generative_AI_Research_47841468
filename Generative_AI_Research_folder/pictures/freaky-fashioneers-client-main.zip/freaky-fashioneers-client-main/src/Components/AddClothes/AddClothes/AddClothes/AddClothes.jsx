import React, { useState, useRef, useEffect } from "react";
import DOMPurify from "dompurify";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "../AddClothes/AddClothes.css";
import { useUserContext } from '../../../../UserContext'; // Import useUserContext

function AddClothes() {
  const navigate = useNavigate();
  const { user } = useUserContext(); // Get user context
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    condition: "",
    size: "",
    location: "",
    photos: [],
  });

  const fileInputRef = useRef(null);

  // Check if the user is logged in
  useEffect(() => {
    if (!user || !user.userId) {
      navigate('/login', { state: { from: { pathname: '/add-clothes' } } });
    }
  }, [user, navigate]);

  const sanitizeInput = (input) => {
    return DOMPurify.sanitize(input); // Sanitize input to prevent XSS
  };

  const handleChange = (e) => {
    const { name, type, value, files } = e.target;

    if (type === "file") {
      // Handle file uploads (no sanitization needed here)
      setFormData((prevState) => ({
        ...prevState,
        [name]: [...prevState[name], ...Array.from(files)],
      }));
    } else {
      // Sanitize input before storing it
      setFormData((prevState) => ({
        ...prevState,
        [name]: sanitizeInput(value),
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formDataToSend = new FormData();

    // Get the userId from localStorage
    const userId = localStorage.getItem("userId");

    // Loop over formData keys and append them to formDataToSend
    for (const key in formData) {
      if (key === "photos") {
        if (formData.photos.length > 0) {
          formData.photos.forEach((file) => {
            formDataToSend.append("photos", file);
          });
        }
      } else {
        formDataToSend.append(key, sanitizeInput(formData[key]));
      }
    }

    // Append the userId to formDataToSend
    formDataToSend.append("user_id", sanitizeInput(userId));

    try {
      console.log("Submitting form...");
      //attempt to send a fetch request to the POST method in the items API
      const response = await fetch(
        "https://freaky-fashioneers-service.onrender.com/items",
        {
          method: "POST",
          body: formDataToSend,
        }
      );

      console.log("Response received:", response);
      //reset fields
      if (response.ok) {
        console.log("Item successfully added!");
        setFormData({
          title: "",
          description: "",
          category: "",
          condition: "",
          size: "",
          location: "",
          photos: [],
        });
        alert("Item successfully added!");
      } else {
        const errorData = await response.json();
        console.error("Failed to add item:", response.status, errorData);
        alert("Failed to add item. Please try again.");
      }
    } catch (error) {
      console.error("Error while posting item:", error);
      alert("An error occurred while adding the item. Please try again.");
    }
  };

  const handleFileClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; // Reset the input value
      fileInputRef.current.click();
    }
  };

  return (
    <div className="add-clothes-container">
      <form onSubmit={handleSubmit} className="add-clothes-form">
        <div className="photo-upload">
          <button
            type="button"
            onClick={handleFileClick}
            className="photo-button"
          >
            <img
              src="/assets/Images/add_photo.png"
              alt="AddClothes"
              className="photo-image"
              style={{ width: "50px", height: "50px", borderRadius: "10%" }}
            />
            Upload Photos
          </button>
          <input
            type="file"
            name="photos"
            onChange={handleChange}
            multiple
            ref={fileInputRef}
            style={{ display: "none" }}
            accept="image/*"
          />
        </div>

        {/* Display selected images names */}
        {formData.photos.length > 0 && (
          <div className="selected-photos">
            <h4>Selected Photos:</h4>
            <ul>
              {formData.photos.map((file, index) => (
                <li key={index}>{file.name}</li>
              ))}
            </ul>
          </div>
        )}

        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleChange}
          placeholder="Title"
          className="input-field"
        />
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Description"
          className="input-field"
        />
        <select
          name="category"
          value={formData.category}
          onChange={handleChange}
          className="input-field"
        >
          <option value="" disabled hidden>
            Select Category
          </option>
          <option value="tops">Tops</option>
          <option value="bottoms">Bottoms</option>
          <option value="dresses">Dresses</option>
          <option value="outerwear">Outerwear</option>
          <option value="sportswear">Sportswear</option>
          <option value="swimwear">Swimwear</option>
          <option value="suits">Suits</option>
          <option value="shoes">Shoes</option>
          <option value="accessories">Accessories</option>
        </select>
        <select
          name="condition"
          value={formData.condition}
          onChange={handleChange}
          className="input-field"
        >
          <option value="" disabled hidden>
            Select Condition
          </option>
          <option value="excellent">Excellent</option>
          <option value="good">Good</option>
          <option value="fair">Fair</option>
          <option value="poor">Poor</option>
        </select>
        <input
          type="text"
          name="size"
          value={formData.size}
          onChange={handleChange}
          placeholder="Size"
          className="input-field"
        />
        <input
          type="text"
          name="location"
          value={formData.location}
          onChange={handleChange}
          placeholder="Location"
          className="input-field"
        />
        <button type="submit" className="publish-button">
          Publish
        </button>
      </form>
    </div>
  );
}

export default AddClothes;
