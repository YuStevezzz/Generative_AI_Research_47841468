// ItemDetails.js

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useUserContext } from '../../UserContext'; // Import user context
import { useSwipeable } from 'react-swipeable'; // Import the useSwipeable hook
import '../ItemDetails/ItemDetails.css';

function ItemDetails() {
  const { user } = useUserContext(); // Get user from context
  const { id } = useParams(); // Get item ID from the URL
  const navigate = useNavigate(); // Hook for navigation
  const [item, setItem] = useState(null);
  const [seller, setSeller] = useState(null);
  const [loading, setLoading] = useState(true); // Initialize loading state
  const [currentImageIndex, setCurrentImageIndex] = useState(0); // State to track current image

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch item details
        const itemResponse = await fetch(`https://freaky-fashioneers-service.onrender.com/items/${id}`);
        if (!itemResponse.ok) {
          throw new Error('Failed to fetch item details');
        }
        const itemData = await itemResponse.json();
        setItem(itemData);

        // Fetch seller details based on the item_id
        const sellerResponse = await fetch(`https://freaky-fashioneers-service.onrender.com/users/seller/${id}`);
        if (!sellerResponse.ok) {
          throw new Error('Failed to fetch seller details');
        }
        const sellerData = await sellerResponse.json();
        setSeller(sellerData);
        console.log("Seller Data:", sellerData);
        setLoading(false); // Set loading to false once data is fetched
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false); // Set loading to false on error
      }
    };

    fetchData();
  }, [id]);

  const handleContactSeller = () => {
    if (!user) {
      navigate('/login'); // Redirect to login if the user is not logged in
    } else {
      // Logic to contact the seller goes here (e.g., open a contact form)
      console.log("User is logged in; allow contacting the seller.");
    }
  };

  // Function to go to the next image
  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % item.photos.length);
  };

  // Function to go to the previous image
  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + item.photos.length) % item.photos.length);
  };

  // Swipe handlers using react-swipeable
  const handlers = useSwipeable({
    onSwipedLeft: () => nextImage(),
    onSwipedRight: () => prevImage(),
    preventDefaultTouchmoveEvent: true,
    trackMouse: true, // Optional: allows swipe with mouse for testing on desktop
  });

  if (loading) {
    return <div>Loading item details...</div>;
  }

  return (
    <div className="item-detail">
      {seller && (
        <div className="seller-info">
          <h3>Seller Information</h3>
          <div className="seller-details">
            <img
              src={seller.profileImage || '/assets/Images/profile.png'}
              alt="Seller profile"
            />
            <p>
              <strong>Username:</strong>
              <span
                onClick={() => navigate(`/other-profile/${seller.username}`)} // Navigate to the OtherProfile page
                style={{ cursor: 'pointer', color: 'blue', textDecoration: 'underline' }}
              >
                {seller.username}
              </span>
            </p>
          </div>
        </div>
      )}

      {item && (
        <>
          <h2 className="item-title">{item.title}</h2>

          <div className="item-image" {...handlers}>
            <img
              src={item.photos[currentImageIndex]}
              alt={item.title}
            />
          </div>

          <div className="item-info">
            <table className="item-details-table">
              <tbody>
                <tr>
                  <td><strong>Description:</strong></td>
                  <td>{item.description}</td>
                </tr>
                <tr>
                  <td><strong>Category:</strong></td>
                  <td>{item.category}</td>
                </tr>
                <tr>
                  <td><strong>Condition:</strong></td>
                  <td>{item.condition}</td>
                </tr>
                <tr>
                  <td><strong>Size:</strong></td>
                  <td>{item.size}</td>
                </tr>
                <tr>
                  <td><strong>Location:</strong></td>
                  <td>{item.location}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="action-buttons">
            <button className="contact-button" onClick={handleContactSeller}>
              Contact Seller
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default ItemDetails;
