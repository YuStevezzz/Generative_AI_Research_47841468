import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import '../Messages/messages.css';

function Chat({ userId }) {
  const { contactId } = useParams(); // Get the contactId from the URL
  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState([]);
  const [contacts, setContacts] = useState([]); // For storing contacts

  // Function to fetch all contacts for the logged-in user
  const fetchContacts = async () => {
    try {
      const response = await fetch(`/api/messages/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch contacts');
      }
      const data = await response.json();
      setContacts(data);
    } catch (error) {
      console.error(error);
    }
  };

  // Function to fetch messages between the logged-in user and the contact
  const fetchMessages = async () => {
    try {
      const response = await fetch(`/api/messages/${userId}/${contactId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch messages');
      }
      const data = await response.json();
      setMessages(data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchContacts(); // Fetch contacts when the component mounts
    fetchMessages(); // Fetch messages when the component mounts
  }, [userId, contactId]);

  // Function to send a new message
  const sendMessage = async () => {
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sender_id: userId,
          receiver_id: contactId,
          message_text: messageText,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      setMessageText(''); // Clear input after sending
      fetchMessages(); // Reload messages after sending
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="chat-container">
      <h2>Chat with User {contactId}</h2>
      <div className="message-list">
        {messages.map((msg) => (
          <div key={msg.message_id} className={msg.sender_id === userId ? 'sent' : 'received'}>
            <p>{msg.message_text}</p>
            <span>{new Date(msg.timestamp).toLocaleString()}</span>
          </div>
        ))}
      </div>
      <textarea 
        value={messageText} 
        onChange={(e) => setMessageText(e.target.value)} 
        placeholder="Type your message..."
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default Chat;
