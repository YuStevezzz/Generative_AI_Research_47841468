import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'; // Ensure you import Link
import '../Landing/Landing.css';

//Landing page

const Landing = () => {
  const [setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const images = [
    'image1.jpg',
    'image2.jpg',
    'image3.jpg',
    'image4.jpg'
  ];

  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [images.length, setCurrentIndex]);


  if (isLoading) {
    return (
      <div className="loader-container">
        <div className="loader"></div>
        <p className="loading-text">Loading...</p>
      </div>
    );
  }

  return (
    <div className="landing-container">
      {/* Hero Section */}
      <div className="hero-section">
        <div className="hero-content">
          <h1>Welcome to <br/>
          Swipe Swap Save
          </h1>
          <p>
            Join our sustainable fashion community and swap your pre-loved fashion with us.
          </p>
          <Link to="/login" className="cta-button">
            Start Swapping Now
          </Link>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="benefits-section">
        <h2>Why Swap With Us?</h2>
        <div className="benefits-container">
          <div className="benefit-card">
            <img
              src="/assets/Images/effortless-trading.jpg"
              alt="Effortless Trading"
              className="benefit-image"
            />
            <h3>Effortless Swapping</h3>
            <p>
              Our platform makes it easy to list, manage, and swap your clothes.
            </p>
          </div>
          <div className="benefit-card">
            <img
              src="/assets/Images/get-new-clothes.jpg"
              alt="Earn Money"
              className="benefit-image"
            />
            <h3>Find Your Style</h3>
            <p>Swap with others to find clothes that tailor your wardrobe to you.</p>
          </div>
          <div className="benefit-card">
            <img
              src="/assets/Images/sustainability-first.jpg"
              alt="Sustainability First"
              className="benefit-image"
            />
            <h3>Sustainability First</h3>
            <p>Join a community that cares about reducing fashion waste.</p>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="how-it-works-section">
        <h2>About Us</h2>
        <div className="steps-container">
          <div className="step-card">
            {/* <h3>Step 1: Sign Up</h3> */}
            {/* <p>Create your free account and set up your seller profile.</p> */}
            <p>
              Welcome to the future of sustainable fashion! <br></br> <br></br> Swapping with us
              means giving your pre-loved clothes a second life while refreshing
              your wardrobe without the waste. It&apos;s more than just trading—it&apos;s
              a commitment to reducing the environmental impact of fast fashion.
              <br></br><br></br>
              Unlike traditional thrift stores, where finding that
              perfect piece can take hours of searching, our platform makes it
              easier than ever to browse and discover items you&apos;ll love. Best of
              all? It&apos;s free! <br></br>
            </p>
          </div>
          {/* <div className="step-card">
            <h3>Step 2: Upload Your Items</h3>
            <p>List your clothes quickly with our easy-to-use platform.</p>
          </div>
          <div className="step-card">
            <h3>Step 3: Sell & Earn</h3>
            <p>Manage your sales and withdraw your earnings anytime.</p>
          </div> */}
          <div>
            <Link className="learn-more" to="/swapping-guide">
              <button>Learn How It Works</button>
              
            </Link>
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="testimonials-section">
        <h2>What Our Users Say</h2>
        <div className="testimonials-container">
          <div className="testimonial-card">
            <p>
            &quot;I swapped my entire wardrobe within weeks. The process was smooth
              and simple!&quot;
            </p>
            <h4>- Alex</h4>
          </div>
          <div className="testimonial-card">
            <p>
            &quot;Finally, a platform that makes swapping pre-loved clothes easy and
              fun.&quot;
            </p>
            <h4>- Jessica</h4>
          </div>
        </div>
      </div>

      {/* Footer CTA Section */}
      <div className="footer-cta">
        <h2>Ready to Start Swapping?</h2>
        <Link to="/login" className="cta-button">
          Sign Up Now
        </Link>
      </div>
    </div>
  );
};

export default Landing;
