import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useUserContext } from "../../UserContext";
import DOMPurify from 'dompurify'; // Import DOMPurify
import "../Login/Login.css";

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [dob, setDob] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useUserContext();

  const from = location.state?.from?.pathname || "/home";

  const isStrongPassword = (password) => {
    //algorithm to ensure the password has at least 8 letters, 1 uppercase, 1 lowercase, 1 number, 1 special digit
    const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;
    return strongPasswordRegex.test(password);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Sanitize user inputs
    const sanitizedUsername = DOMPurify.sanitize(username);
    const sanitizedPassword = DOMPurify.sanitize(password);
    const sanitizedName = DOMPurify.sanitize(name);
    const sanitizedEmail = DOMPurify.sanitize(email);
    const sanitizedPhoneNumber = DOMPurify.sanitize(phoneNumber);
    const sanitizedDob = DOMPurify.sanitize(dob);

    if (isLogin) {
      // Login logic
      try {
        // Send login request to the server
        const response = await fetch(
          "https://freaky-fashioneers-service.onrender.com/users/login",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            // Send sanitized username and password in the request body
            body: JSON.stringify({ username: sanitizedUsername, password: sanitizedPassword }),
          }
        );

        if (!response.ok) {
          throw new Error("Login failed");
        }

        const data = await response.json();
        console.log("User logged in successfully:", data);
        // Store required user data in localStorage
        const items = {
          token: data.token,
          userId: data.userId,
          username: data.username,
          name: data.name,
          email: data.email,
          phone_number: data.phone_number,
          dob: data.dob
        };

        for (const [key, value] of Object.entries(items)) {
          // Save user data to localStorage
          localStorage.setItem(key, value);
        }

        login({ username: sanitizedUsername, userId: data.userId });
        
        navigate(from, { replace: true });
      } catch (error) {
        setError("Error logging in. Please try again.");
        console.error(error);
      }
    } else {
      // Signup logic
      // Check if all fields are filled in
      if (!sanitizedUsername || !sanitizedName || !sanitizedEmail || !sanitizedPhoneNumber || !sanitizedDob || !sanitizedPassword) {
        setError("Please fill in all fields");
        return;
      }
      // Validate strong password
      if (!isStrongPassword(sanitizedPassword)) {
        setError("Password must be at least 8 characters long, with at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character.");
        return;
      }

      try {
        // Format date of birth to a locale-specific string
        const formattedDob = new Date(sanitizedDob).toLocaleDateString("en-US");
        // Send signup request to the server
        const response = await fetch(
          "https://freaky-fashioneers-service.onrender.com/users",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            // Send sanitized user data in the request body
            body: JSON.stringify({
              username: sanitizedUsername,
              name: sanitizedName,
              email: sanitizedEmail,
              phone_number: sanitizedPhoneNumber,
              dob: formattedDob,
              password: sanitizedPassword,
            }),
          }
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.json();
        console.log("User signed up successfully:", data);
        setIsLogin(true);
      } catch (error) {
        setError("Error signing up. Please try again.");
        console.error(error);
      }
    }

    // Clear form fields after submission
    setUsername("");
    setPassword("");
    setName("");
    setEmail("");
    setPhoneNumber("");
    setDob("");
    setError("");
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h2>{isLogin ? "Login" : "Sign Up"}</h2>
        {error && <p className="error">{error}</p>}
        <form onSubmit={handleSubmit}>
          {!isLogin && (
            <>
              <div className="form-group">
                <label htmlFor="name">Name:</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required={!isLogin}
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required={!isLogin}
                />
              </div>
              <div className="form-group">
                <label htmlFor="phoneNumber">Phone Number:</label>
                <input
                  type="tel"
                  id="phoneNumber"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  required={!isLogin}
                />
              </div>
              <div className="form-group">
                <label htmlFor="dob">Date of Birth:</label>
                <input
                  type="date"
                  id="dob"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  required={!isLogin}
                />
              </div>
            </>
          )}
          <div className="form-group">
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit">{isLogin ? "Login" : "Sign Up"}</button>
        </form>
        <p>
          {isLogin ? "Don't have an account?" : "Already have an account?"}
          <button
            className="toggle-button"
            onClick={() => setIsLogin(!isLogin)}
          >
            {isLogin ? "Sign Up" : "Login"}
          </button>
        </p>
      </div>
    </div>
  );
};

export default Login;
